


insert  into time_slot_entity values (10001,'11AM-1PM',1);
insert  into time_slot_entity values (10002,'1PM-3PM',2);
insert  into time_slot_entity values (10003,'3PM-5PM',3);
insert  into time_slot_entity values (10004,'5PM-7PM',4);
--------------------------------------------------------------------
insert  into table_entity values (10001,'table1');
insert  into table_entity values (10002,'table2');
insert  into table_entity values (10003,'table3');
insert  into table_entity values (10004,'table4');
insert  into table_entity values (10005,'table5');
insert  into table_entity values (10006,'table6');
insert  into table_entity values (10007,'table7');
insert  into table_entity values (10008,'table8');
insert  into table_entity values (10009,'table9');
insert  into table_entity values (10010,'table10');
insert  into table_entity values (10011,'table11');
insert  into table_entity values (10012,'table12');
insert  into table_entity values (10013,'table13');
insert  into table_entity values (10014,'table14');
insert  into table_entity values (10015,'table15');
insert  into table_entity values (10016,'table16');
insert  into table_entity values (10017,'table17');
insert  into table_entity values (10018,'table18');
insert  into table_entity values (10019,'table19');
insert  into table_entity values (10020,'table20');