package com.mehrdadmaeen.reservationsystem;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;



import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ReservationTest {


    @BeforeAll
    static void beforeAll(){

    }
    @AfterAll
    static void afterAll(){
    }
    @BeforeEach
    void beforeEach(TestInfo info){

    }
    @AfterEach
    void afterEach(TestInfo info){

    }
    @Test
    void duplicateReservationTest(){

    }

    @Test
    @ParameterizedTest
    @CsvSource(value = {})
    @DisplayName("")
    void retrieveAvailableSlotsTest(){

    }













}